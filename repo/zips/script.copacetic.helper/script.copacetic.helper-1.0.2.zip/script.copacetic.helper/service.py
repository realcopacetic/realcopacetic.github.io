#!/usr/bin/python
# coding: utf-8
# author: realcopacetic

from resources.lib.service.monitor import Monitor

if __name__ == "__main__":
    Monitor()
