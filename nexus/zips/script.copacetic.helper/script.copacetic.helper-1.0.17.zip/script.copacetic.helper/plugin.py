# author: realcopacetic, sualfred

from resources.lib.plugin.main import Main

if __name__ == '__main__':
    Main()
